# module-nsupdate

Module to create and delete DNS records by using nsupdate
