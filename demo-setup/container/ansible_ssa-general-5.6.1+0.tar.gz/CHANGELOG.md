# Changelog

Find a list of all releases on [GitLab](https://gitlab.com/ansible-ssa/collection-ansible_ssa-general/-/releases).
