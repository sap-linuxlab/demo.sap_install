# Ansible Role: eda_controller_setup

This role applies base configuration for EDA controllers.
