# role-automationhub-content

Configure private automation hub e.g. synchronize content from Ansible Galaxy.
